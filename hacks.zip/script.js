  document.addEventListener('DOMContentLoaded', function () {
      var unblockButton = document.getElementById('unblockButton');
      var sound = document.getElementById('sound');

      unblockButton.addEventListener('click', function() {
          sound.play();
      });
  });
